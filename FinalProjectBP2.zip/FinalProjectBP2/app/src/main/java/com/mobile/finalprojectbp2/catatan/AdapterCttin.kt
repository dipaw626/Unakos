//package com.mobile.finalprojectbp2.catatan
//
//import android.content.Context
//import android.graphics.Bitmap
//import android.graphics.BitmapFactory
//import android.view.LayoutInflater
//import android.view.View
//import android.view.ViewGroup
//import android.widget.Button
//import android.widget.ImageView
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//import com.mobile.finalprojectbp2.Main.AdapterImage
//import com.mobile.finalprojectbp2.Main.MainModel
//import com.mobile.finalprojectbp2.R
////import com.mobile.finalprojectbp2.catatan.CatatanModel
//import java.io.ByteArrayInputStream
//
//class AdapterCttin(
//    private val listCatatan: List<MainModel>,
//    private val listener: onAdapterListener
//
//) : RecyclerView.Adapter<AdapterCttin.HistoryViewHolder>()
//{
//
//    inner class HistoryViewHolder(v: View):RecyclerView.ViewHolder(v) {
//        //            val textId: TextView
//        val tvjudul: TextView
//        val tvNominal: TextView
//        val tvTanggal: TextView
//
//        //            val tvCatatan: TextView
//        val imagedetail: ImageView
//
//
//        init {
////                textId = v.findViewById(R.id.textIdMakanan)
//            tvjudul = v.findViewById(R.id.item_namactt)
//            tvNominal = v.findViewById(R.id.item_costctt)
//            tvTanggal = v.findViewById(R.id.item_tglctt)
////                tvCatatan = v.findViewById(R.id.tvDetailnote)
//            imagedetail = v.findViewById(R.id.item_fotoctt)
////                imagedetail.setOnClickListener{
////                    DetailActivity.imagedetail = imagedetail.drawable.toBitmap(30,30,null)
////                }
//
//
//        }
//
//        fun bind(dt: MainModel) {
////                val id:Int = data.id
//            val nama: String = dt.nama
//            val cost: Int = dt.nominal
//            val tgl: String = dt.tanggal
//            val gambar: ByteArray = dt.image
//
//
////                textId.text = id.toString()
//            tvjudul.text = nama
//            tvNominal.text = cost.toString()
//            tvTanggal.text = tgl
//
//
//            val byteInputStream = ByteArrayInputStream(gambar)
//            val imagebmp: Bitmap = BitmapFactory.decodeStream(byteInputStream)
//            imagedetail.setImageBitmap(imagebmp)
//
//        }
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AdapterCttin.HistoryViewHolder{
//        val layoutInflater = LayoutInflater.from(parent?.context)
//        val cellForRow = layoutInflater.inflate(R.layout.cardview_catatan_in, parent, false)
//        return HistoryViewHolder((cellForRow))
//}
//
//    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
//        val main = listCatatan[position]
//        holder.bind(listCatatan[position])
////        holder.foto.setImageResource(main.image)
////        holder.nama.text = main.nama
////        holder.nominal.text = main.nominal
////        holder.tgl.text = main.tanggal
//
//        holder.itemView.setOnClickListener{
//            listener.onClick( main )
//        }
//
//    }
//
//    override fun getItemCount(): Int {
//        return listCatatan.size
//    }
//
////    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
////        val foto = view.findViewById<ImageView>(R.id.item_foto)
////        val nama = view.findViewById<TextView>(R.id.item_nama)
////        val nominal = view.findViewById<TextView>(R.id.item_cost)
////        val tgl = view.findViewById<TextView>(R.id.item_tgl)
////
////    }
//
//    interface  onAdapterListener {
//        fun onClick(main: MainModel)
//    }
//
//
//
//}