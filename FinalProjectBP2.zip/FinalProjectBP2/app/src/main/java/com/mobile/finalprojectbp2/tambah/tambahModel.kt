package com.mobile.finalprojectbp2.tambah

import android.graphics.Bitmap
import android.widget.ImageView
import java.time.DateTimeException
import java.util.*

class tambahModel(
    var id: String,
    var name: String,
    var nominal: Int,
    var tanggal: String,
    var keterangan: String,
    var image: Bitmap
)
