//package com.mobile.finalprojectbp2.catatan
//
//import android.graphics.Bitmap
//
//data class CatatanModel(
//    val id: Int,
//    val image: ByteArray,
//    val nama: String,
//    val nominal: Int,
//    val tanggal: String,
//    val keterangan: String
//
//)
